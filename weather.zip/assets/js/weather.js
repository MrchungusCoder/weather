


let loadDayForecastData = () => {
	
}

let loadWeekForecastData = () => {
	
	
}


loadDayForecastData();
loadWeekForecastData();